<?php $__env->startSection('admintitle'); ?>
    Ambulance
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboardContent'); ?>
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <div class="br-mainpanel">
        <div class="br-pagetitle d-flex justify-content-between align-items-center">
            <i class="icon ion-ios-box-outline"></i>
            <div>
                <h4>Ambulance</h4>
                <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
            </div>
            <div class="ml-auto">
                <a href="<?php echo e(route('admin.ambulance.create')); ?>" class="btn btn-primary">Create</a>
            </div>
        </div>


       <div class="br-pagebody">
        <div class="br-section-wrapper">


          

          <div class="table-wrapper">
            <table id="datatable2" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">#SL</th>
                  <th class="wd-15p">Name</th>
                  <th class="wd-15p">Vehicle Number</th>
                  <th class="wd-15p">Driver Name</th>
                  <th class="wd-15p">Location</th>
                  <th class="wd-15p">Availability</th>
                  <th class="wd-15p">price</th>
                  <th class="wd-20p">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $sl = 1
                ?>
                <?php if($ambulances->count() > 0): ?>
                <?php $__currentLoopData = $ambulances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambulance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                        <td><?php echo e($sl++); ?></td>
                        <td><?php echo e($ambulance->name); ?></td>
                        <td><?php echo e($ambulance->vehicle_number); ?></td>
                        <td><?php echo e($ambulance->driver_name); ?></td>
                        <td><?php echo e($ambulance->location); ?></td>
                        <td><?php echo e($ambulance->availability); ?></td>
                        <td><?php echo e($ambulance->price_per_km); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.ambulance.show', $ambulance->id )); ?>" class="btn btn-sm btn-success mr-1"><i class="fa fa-eye"></i></a>
                            <a href="<?php echo e(route('admin.ambulance.edit', $ambulance->id)); ?>" class="btn btn-sm btn-primary mr-1"><i class="fa fa-edit"></i></a>
                            <form action="<?php echo e(route('admin.ambulance.delete', $ambulance->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this Ambulance?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger"><i class="fa fa-trash"></i></button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <th class="text-center text-danger text-bold" colspan="6">No products available.</th>
                <?php endif; ?>
              </tbody>
            </table>
          </div><!--    table-wrapper -->


        </div><!-- br-section-wrapper -->
      </div>
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js__'); ?>
<script>
        $('#datatable2').DataTable({
        bLengthChange: false,
        searching: false,
        responsive: true
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\ambulance\index.blade.php ENDPATH**/ ?>