<?php $__env->startSection('admintitle'); ?>
    Confirm Orders List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
     <!-- ########## START: LEFT PANEL ########## -->
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: LEFT PANEL ########## -->

     <!-- ########## START: HEAD PANEL ########## -->
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: HEAD PANEL ########## -->

     <!-- ########## START: RIGHT PANEL ########## -->
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: RIGHT PANEL ########## -->

     <!-- ########## START: MAIN PANEL ########## -->
     <div class="br-mainpanel">
       <div class="br-pagetitle">
         <i class="icon ion-ios-photos-outline"></i>
         <div>
           <h4>Confirm Orders List</h4>
           <p class="mg-b-0">Manage orders and their statuses.</p>
         </div>
       </div>

       <div class="br-pagebody">
        <div class="br-section-wrapper">
            <h6 class="br-section-label">Confirm Orders List</h6>
            <p class="br-section-text">Using the most basic table markup.</p>

            <!-- Filter Buttons for Order Status -->
            

            <!-- Orders Table -->
            <div class="bd bd-gray-300 rounded table-responsive">
              <table class="table mg-b-0" id="confirmtable">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>City</th>
                    <th>State</th>
                    <th>Post Code</th>
                    <th>Address</th>
                    <th>Street Address</th>
                    <th>Phone</th>
                    <th>Status</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $confirmList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                    <td><?php echo e($order->city); ?></td>
                    <td><?php echo e($order->state_county); ?></td>
                    <td><?php echo e($order->postcode); ?></td>
                    <td><?php echo e($order->address); ?></td>
                    <td><?php echo e($order->street_address); ?></td>
                    <td><?php echo e($order->phone); ?></td>
                    <td>
                        <form action="<?php echo e(route('admin.orders.updateStatus', $order->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="form-group">
                                <select name="status" class="form-control" onchange="this.form.submit()">
                                    <option value="Canceled" <?php echo e($order->status == 'Canceled' ? 'selected' : ''); ?>>Canceled</option>
                                    <option value="Delivered" <?php echo e($order->status == 'Delivered' ? 'selected' : ''); ?>>Delivered</option>
                                </select>
                            </div>
                        </form>
                    </td>
                    <td>
                        <a href="<?php echo e(route('admin.orders.details', $order->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
            </div>
        </div>
       </div><!-- br-pagebody -->

       <!-- Include Footer -->
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\orders\confirmOrder.blade.php ENDPATH**/ ?>