

<?php $__env->startSection('admintitle'); ?>
    Write Prescription
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
    <?php echo $__env->make('doctors.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('doctors.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="br-mainpanel">
        <div class="br-pagetitle">
            <i class="icon ion-ios-medkit-outline"></i>
            <div>
                <h4>Write a Prescription</h4>
                <p class="mg-b-0">Select patient and prescribe medicine.</p>
            </div>
        </div>

        <div class="br-pagebody">
            <div class="br-section-wrapper">

                <?php if(session('success')): ?>
                    <div class="alert alert-success"><?php echo e(session('success')); ?></div>
                <?php endif; ?>

                <form action="<?php echo e(route('doctor.prescribe.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label for="appointment_id">Select Patient</label>
                        <select name="appointment_id" class="form-control" required>
                            <option value="">-- Select --</option>
                            <?php $__currentLoopData = $appointments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($appointment->id); ?>">
                                    <?php echo e($appointment->patient_name); ?> (<?php echo e($appointment->appointment_date); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>

                    <div id="medicine-section">
                        <label>Medicines</label>
                        <div class="row mb-2 medicine-group">
                            <div class="col-md-4">
                                <input type="text" name="medicineName[]" class="form-control" placeholder="Medicine Name" required>
                            </div>
                            <div class="col-md-2">
                                <input type="checkbox" name="doseMorning[]" value="morning"> Morning
                            </div>
                            <div class="col-md-2">
                                <input type="checkbox" name="doseAfternoon[]" value="afternoon"> Afternoon
                            </div>
                            <div class="col-md-2">
                                <input type="checkbox" name="doseNight[]" value="night"> Night
                            </div>
                            <div class="col-md-2">
                                <button type="button" class="btn btn-danger btn-sm remove-medicine">X</button>
                            </div>
                        </div>
                    </div>

                    <button type="button" id="add-medicine" class="btn btn-sm btn-info mb-3">+ Add Another Medicine</button>

                    <div class="form-group">
                        <label for="medicine_duration">Medicine Duration (days)</label>
                        <input type="number" name="medicine_duration" class="form-control" required>
                    </div>

                    <button type="submit" class="btn btn-primary">Submit Prescription</button>
                </form>
            </div>
        </div>

        <?php echo $__env->make('doctors.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js__'); ?>
<script>
    $(document).ready(function() {
        $('#add-medicine').click(function() {
            let group = $('.medicine-group').first().clone();
            group.find('input').val('');
            group.find('input[type="checkbox"]').prop('checked', false);
            $('#medicine-section').append(group);
        });

        $(document).on('click', '.remove-medicine', function() {
            if ($('.medicine-group').length > 1) {
                $(this).closest('.medicine-group').remove();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctors.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\doctors\prescribe.blade.php ENDPATH**/ ?>