<div class="header-bottom mb-0 header-sticky stick d-none d-lg-block d-xl-block">

    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <!-- Begin Header Bottom Menu Area -->
                <div class="hb-menu jj">
                    <nav>
                        <ul>
                            <li class=""><a href="<?php echo e(route('home')); ?>">Home</a>
                            </li>
                            <li class="megamenu-holder ">
                                <a href="#">Category</a>
                                <ul class="megamenu hb-megamenu">
                                    <li><a href="#">Shop Page Layout</a>
                                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <ul>
                                            <li><a href="<?php echo e(route('category.products', $category->id)); ?>"><?php echo e($category->category_name); ?></a></li>
                                        </ul>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </li>
                                </ul>
                            </li>
                            <li class=""><a href="">Find Doctor</a>
                            <li class=""><a href="">Service</a>
                            <li class=""><a href="">FInd Ambulance</a>
                            <li class=""><a href="">About US</a>

                            
                            
                        </ul>
                    </nav>
                </div>
                <!-- Header Bottom Menu Area End Here -->
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\website\layout\menuBar.blade.php ENDPATH**/ ?>