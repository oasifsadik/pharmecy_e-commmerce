    <!-- Place favicon.png in the root directory -->
    <link rel="shortcut icon" href="{{ asset('medWeb') }}/img/favicon.png" type="image/x-icon" />
    <!-- Font Icons css -->
    <link rel="stylesheet" href="{{ asset('medWeb') }}/css/font-icons.css">
    <!-- plugins css -->
    <link rel="stylesheet" href="{{ asset('medWeb') }}/css/plugins.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="{{ asset('medWeb') }}/css/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="{{ asset('medWeb') }}/css/responsive.css">
    {{-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css"> --}}

