    <!-- Place favicon.png in the root directory -->
    <link rel="shortcut icon" href="<?php echo e(asset('medWeb')); ?>/img/favicon.png" type="image/x-icon" />
    <!-- Font Icons css -->
    <link rel="stylesheet" href="<?php echo e(asset('medWeb')); ?>/css/font-icons.css">
    <!-- plugins css -->
    <link rel="stylesheet" href="<?php echo e(asset('medWeb')); ?>/css/plugins.css">
    <!-- Main Stylesheet -->
    <link rel="stylesheet" href="<?php echo e(asset('medWeb')); ?>/css/style.css">
    <!-- Responsive css -->
    <link rel="stylesheet" href="<?php echo e(asset('medWeb')); ?>/css/responsive.css">
    

<?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views/medWebsite/partials/head.blade.php ENDPATH**/ ?>