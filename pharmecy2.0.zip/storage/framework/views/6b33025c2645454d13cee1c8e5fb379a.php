

<?php $__env->startSection('admintitle'); ?>
    Order Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
    <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="br-mainpanel">
        <div class="br-pagetitle">
            <i class="icon ion-ios-photos-outline"></i>
            <div>
                <h4>Order Details</h4>
                <p class="mg-b-0">Detailed view of the order.</p>
            </div>
        </div>

        <div class="br-pagebody">
            <div class="br-section-wrapper">

                
                <h6 class="br-section-label">Order Information</h6>
                <p class="br-section-text">Details of the selected order.</p>

                <?php if($orderDetails->items->count()): ?>
                    
                    <div class="bd bd-gray-300 rounded table-responsive">
                        <table class="table mg-b-0">
                            <thead>
                                <tr>
                                    <th>Product</th>
                                    <th>Thumbnail</th>
                                    <th>Quantity</th>
                                    <th>Price</th>
                                    <th>Subtotal</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $orderDetails->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($item->product_name); ?></td>
                                        <td>
                                            <?php if($item->product && $item->product->thumbnail): ?>
                                                <img src="<?php echo e(asset('storage/' . $item->product->thumbnail)); ?>" height="80px" alt="<?php echo e($item->product_name); ?>">
                                            <?php else: ?>
                                                <img src="<?php echo e(asset('images/no-image.png')); ?>" height="80px" alt="No Image">
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->quantity); ?></td>
                                        <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                                        <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                    <td>$<?php echo e($orderDetails->total_price); ?></td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                <?php else: ?>
                    
                    <div class="mt-4">
                        <h6>Prescription Information</h6>
                        <?php $prescription = $orderDetails->prescribMedicine->first(); ?>

                        <?php if($prescription): ?>
                            <p><strong>Type:</strong> <?php echo e(ucfirst($prescription->type)); ?></p>
                            <p><strong>Phone:</strong> <?php echo e($prescription->phone); ?></p>
                            <p><strong>Medicine Duration:</strong> <?php echo e($prescription->medicine_duration); ?> days</p>
                            <p><strong>Reminder:</strong> <?php echo e($prescription->reminder ? 'Yes' : 'No'); ?></p>

                            <?php if($prescription->type === 'upload'): ?>
                                <p><strong>Prescription File:</strong></p>
                                <a href="<?php echo e(asset('storage/' . $prescription->file)); ?>" target="_blank">View Prescription</a>
                                <?php elseif($prescription->type === 'manual'): ?>
                                    <?php
                                        $medicines = is_array($prescription->medicines)
                                            ? $prescription->medicines
                                            : json_decode($prescription->medicines, true);
                                    ?>

                                <?php if(is_array($medicines)): ?>
                                    <table class="table table-bordered mt-2">
                                        <thead>
                                            <tr>
                                                <th>Medicine Name</th>
                                                <th>Morning</th>
                                                <th>Afternoon</th>
                                                <th>Night</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $medicines; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $med): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        // Get doses for morning, afternoon, and night (default to 0 if not provided)
                                                        $morning = (int)($med['doses']['morning'] ?? 0);
                                                        $afternoon = (int)($med['doses']['afternoon'] ?? 0);
                                                        $night = (int)($med['doses']['night'] ?? 0);
                                                        
                                                        // Calculate total doses for this medicine per day
                                                        $dailyTotal = $morning + $afternoon + $night;

                                                        // Calculate the total doses required for the entire duration of the prescription
                                                        $totalDoses = $dailyTotal * $prescription->medicine_duration;
                                                    ?>

                                                    <tr>
                                                        <td><?php echo e($med['name']); ?><br>
                                                            <small class=" text-danger"><strong class="text-dark">Total Doses for <?php echo e($prescription->medicine_duration); ?> days:</strong> <?php echo e($totalDoses); ?></small>
                                                        </td>
                                                        <td><?php echo e($morning); ?></td>
                                                        <td><?php echo e($afternoon); ?></td>
                                                        <td><?php echo e($night); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                                        </tbody>
                                    </table>
                                <?php else: ?>
                                    <p class="text-danger">Invalid medicine format.</p>
                                <?php endif; ?>

                                <?php endif; ?>
                            <?php else: ?>
                            <p class="text-danger">No prescription data found.</p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                
                <div class="mt-4">
                    <h6>Customer Details</h6>
                    <p><strong>Name:</strong> <?php echo e($orderDetails->first_name); ?> <?php echo e($orderDetails->last_name); ?></p>
                    <p><strong>City:</strong> <?php echo e($orderDetails->city); ?></p>
                    <p><strong>State:</strong> <?php echo e($orderDetails->state_county); ?></p>
                    <p><strong>Post Code:</strong> <?php echo e($orderDetails->postcode); ?></p>
                    <p><strong>Address:</strong> <?php echo e($orderDetails->address); ?></p>
                    <p><strong>Street Address:</strong> <?php echo e($orderDetails->street_address); ?></p>
                    <p><strong>Phone:</strong> <?php echo e($orderDetails->phone); ?></p>
                </div>

                
                <div class="mt-4">
                    <form action="<?php echo e(route('admin.order.confirm', $orderDetails->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Confirm Order</button>
                    </form>
                </div>

            </div>
        </div>

        <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\prescribOrder\orderDetails.blade.php ENDPATH**/ ?>