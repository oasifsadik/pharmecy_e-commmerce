<?php $__env->startSection('admintitle'); ?>
    Categories
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboardContent'); ?>
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <div class="br-mainpanel">
        <div class="br-pagetitle d-flex justify-content-between align-items-center">
            <i class="icon ion-ios-folder-outline"></i>
            <div>
                <h4>Categories</h4>
                <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
            </div>
            <div class="ml-auto">
                <a href="<?php echo e(route('category.create')); ?>" class="btn btn-primary">Create</a>
            </div>
        </div>


       <div class="br-pagebody">
        <div class="br-section-wrapper">


          

          <div class="table-wrapper">
            <table id="datatable2" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">#SL</th>
                  <th class="wd-15p">Category name</th>
                  <th class="wd-15p">Category Description</th>
                  <th class="wd-20p">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $sl = 1
                ?>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($sl++); ?></td>
                        <td><?php echo e($category->category_name); ?></td>
                        <?php ($pDesc = strip_tags(htmlspecialchars_decode($category->category_description))); ?>

                        <td><?php echo (strlen($pDesc) > 20) ? substr($pDesc,0,50).'...' : $pDesc; ?></td>
                        <td>
                            <a href="<?php echo e(route('category.show', $category->id )); ?>" class="btn btn-sm btn-success mr-1">Show</a>
                            <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-sm btn-primary mr-1">Edit</a>
                            <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST" class="d-inline" onsubmit="return confirm('Are you sure you want to delete this Category?');">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button type="submit" class="btn btn-sm btn-danger">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
            </table>
          </div><!-- table-wrapper -->


        </div><!-- br-section-wrapper -->
      </div>
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js__'); ?>
<script>
    $('#datatable2').DataTable({
        bLengthChange: false,
        searching: false,
        responsive: true
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\category\index.blade.php ENDPATH**/ ?>