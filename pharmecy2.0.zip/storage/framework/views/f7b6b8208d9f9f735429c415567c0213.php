<?php $__env->startSection('medwebtitle', 'Registration'); ?>

<?php $__env->startSection('medWebContent'); ?>
<!-- BREADCRUMB AREA START -->
<div class="ltn__breadcrumb-area text-left bg-overlay-white-30 bg-image" data-bs-bg="img/bg/14.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="ltn__breadcrumb-inner">
                    <h1 class="page-title">Account</h1>
                    <div class="ltn__breadcrumb-list">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>"><i class="fas fa-home"></i> Home</a></li>
                            <li>Register</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- BREADCRUMB AREA END -->

<!-- REGISTRATION AREA START -->
<div class="ltn__login-area pb-110">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <h1 class="section-title">Register Your Account</h1>
                <p>Please fill out the form below to create your account.</p>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-lg-8">
                <div class="account-login-inner">
                    <?php if($errors->any()): ?>
                        <div class="alert alert-danger">
                            <ul class="mb-0">
                                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($error); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    <?php endif; ?>

                    <form action="<?php echo e(route('register')); ?>" method="POST" class="ltn__form-box contact-form-box">
                        <?php echo csrf_field(); ?>

                        <div class="row">
                            <div class="col-md-6">
                                <input type="text" name="first_name" placeholder="First Name*" value="<?php echo e(old('first_name')); ?>">
                            </div>
                            <div class="col-md-6">
                                <input type="text" name="last_name" placeholder="Last Name*" value="<?php echo e(old('last_name')); ?>">
                            </div>
                            <div class="col-md-12">
                                <input type="text" name="company_name" placeholder="Company Name (Optional)" value="<?php echo e(old('company_name')); ?>">
                                <input type="text" name="address" placeholder="Street Address*" value="<?php echo e(old('address')); ?>">
                                <input type="text" name="street_address" placeholder="Apartment, suite, unit (Optional)" value="<?php echo e(old('street_address')); ?>">
                                <input type="text" name="city" placeholder="City*" value="<?php echo e(old('city')); ?>">
                                <input type="text" name="state_county" placeholder="State / County*" value="<?php echo e(old('state_county')); ?>">

                                <select name="country" class="form-control">
                                    <option value="">Select Country*</option>
                                    <option value="Bangladesh" <?php echo e(old('country') == 'Bangladesh' ? 'selected' : ''); ?>>Bangladesh</option>
                                    <option value="India" <?php echo e(old('country') == 'India' ? 'selected' : ''); ?>>India</option>
                                    <option value="United States" <?php echo e(old('country') == 'United States' ? 'selected' : ''); ?>>United States</option>
                                    <option value="United Kingdom" <?php echo e(old('country') == 'United Kingdom' ? 'selected' : ''); ?>>United Kingdom</option>
                                    <!-- Add more countries if needed -->
                                </select>

                                <input type="text" name="postcode" placeholder="Postcode / Zip*" value="<?php echo e(old('postcode')); ?>">
                                <input type="email" name="email" placeholder="Email Address*" value="<?php echo e(old('email')); ?>">
                                <input type="text" name="phone" placeholder="Phone Number*" value="<?php echo e(old('phone')); ?>">
                                <input type="password" name="password" placeholder="Password*">
                                <input type="password" name="password_confirmation" placeholder="Confirm Password*">
                            </div>

                            <div class="col-md-12">
                                <label class="checkbox-inline">
                                    <input type="checkbox" required>
                                    I agree to the <a href="#">Privacy Policy</a> & <a href="#">Terms of Use</a>.
                                </label>
                            </div>

                            <div class="col-md-12 mt-20">
                                <button class="theme-btn-1 btn reverse-color btn-block" type="submit">Create Account</button>
                            </div>

                            <div class="col-md-12 text-center mt-3">
                                <a href="<?php echo e(route('login')); ?>">Already have an account? Login</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- REGISTRATION AREA END -->

<!-- CALL TO ACTION START -->
<div class="ltn__call-to-action-area call-to-action-6 before-bg-bottom" data-bs-bg="img/1.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="call-to-action-inner ltn__secondary-bg text-center">
                    <h1 class="text-white">Buy medical disposable face mask <br> to protect your loved ones</h1>
                    <a class="btn btn-effect-3 btn-white mt-3" href="shop.html">Explore Products <i class="icon-next"></i></a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- CALL TO ACTION END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('medWebsite.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\medWebsite\auth\register.blade.php ENDPATH**/ ?>