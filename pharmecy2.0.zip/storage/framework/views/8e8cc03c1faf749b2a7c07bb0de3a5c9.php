<?php $__env->startSection('admintitle'); ?>
    Ambulance
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboardContent'); ?>
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <div class="br-mainpanel">
        <div class="br-pagetitle d-flex justify-content-between align-items-center">
            <i class="icon ion-ios-box-outline"></i>
            <div>
                <h4>Ambulance</h4>
                <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
            </div>
            <div class="ml-auto">
            </div>
        </div>


       <div class="br-pagebody">
        <div class="br-section-wrapper">


          

          <div class="table-wrapper">
            <table id="datatable2" class="table display responsive nowrap">
              <thead>
                <tr>
                  <th class="wd-15p">#SL</th>
                  <th class="wd-15p">User Name</th>
                  <th class="wd-15p">contact_number </th>
                  <th class="wd-15p">pickup_location </th>
                  <th class="wd-15p">drop_location</th>
                  <th class="wd-15p">pickup_time</th>
                  <th class="wd-15p">distance</th>
                  <th class="wd-15p">price</th>
                  <th class="wd-20p">Action</th>
                </tr>
              </thead>
              <tbody>
                <?php
                    $sl = 1
                ?>
                <?php if($ambulanceBookings->count() > 0): ?>
                <?php $__currentLoopData = $ambulanceBookings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ambulance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr >
                        <td><?php echo e($sl++); ?></td>
                        <td><?php echo e($ambulance->user->first_name); ?> <?php echo e($ambulance->user->last_name); ?></td>
                        <td><?php echo e($ambulance->contact_number); ?></td>
                        <td><?php echo e($ambulance->pickup_location); ?></td>
                        <td><?php echo e($ambulance->drop_location); ?></td>
                        <td><?php echo e($ambulance->pickup_time); ?></td>
                        <td><?php echo e($ambulance->distance); ?></td>
                        <td><?php echo e($ambulance->price); ?></td>
                        <td>
                            <a href="<?php echo e(route('admin.ambulance.booking.show', $ambulance->id )); ?>" class="btn btn-sm btn-success mr-1"><i class="fa fa-eye"></i></a>
                            
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                <th class="text-center text-danger text-bold" colspan="6">No products available.</th>
                <?php endif; ?>
              </tbody>
            </table>
          </div><!--    table-wrapper -->


        </div><!-- br-section-wrapper -->
      </div>
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js__'); ?>
<script>
        $('#datatable2').DataTable({
        bLengthChange: false,
        searching: false,
        responsive: true
    });

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\ambulanceBooking\index.blade.php ENDPATH**/ ?>