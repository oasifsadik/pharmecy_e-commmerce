    <!-- All JS Plugins -->
    <script src="<?php echo e(asset('medWeb')); ?>/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="<?php echo e(asset('medWeb')); ?>/js/main.js"></script>
    <?php echo $__env->yieldContent('font-js'); ?>
<?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views/medWebsite/partials/footerJs.blade.php ENDPATH**/ ?>