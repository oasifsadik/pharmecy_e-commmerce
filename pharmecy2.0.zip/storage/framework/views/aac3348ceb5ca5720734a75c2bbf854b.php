<?php $__env->startSection('admintitle'); ?>
    Order Details
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
    <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="br-mainpanel">
        <div class="br-pagetitle">
            <i class="icon ion-ios-photos-outline"></i>
            <div>
                <h4>Order Details</h4>
                <p class="mg-b-0">Detailed view of the order.</p>
            </div>
        </div>

        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <h6 class="br-section-label">Order Information</h6>
                <p class="br-section-text">Details of the selected order.</p>

                <div class="bd bd-gray-300 rounded table-responsive">
                    <table class="table mg-b-0">
                        <thead>
                            <tr>
                                <th>Product</th>
                                <th>Thumbnail</th>
                                <th>Quantity</th>
                                <th>Price</th>
                                <th>Subtotal</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $orderDetails->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($item->product_name); ?></td>
                                    <td>
                                        <?php if($item->product && $item->product->thumbnail): ?>
                                            <img src="<?php echo e(asset('storage/' . $item->product->thumbnail)); ?>" height="80px" alt="<?php echo e($item->product_name); ?>">
                                        <?php else: ?>
                                            <img src="<?php echo e(asset('images/no-image.png')); ?>" height="80px" alt="No Image">
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->quantity); ?></td>
                                    <td>$<?php echo e(number_format($item->price, 2)); ?></td>
                                    <td>$<?php echo e(number_format($item->price * $item->quantity, 2)); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="4" class="text-right"><strong>Total:</strong></td>
                                <td>$<?php echo e($orderDetails->total_price); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="mt-4">
                    <h6>Customer Details</h6>
                    <p>Name: <?php echo e($orderDetails->first_name); ?> <?php echo e($orderDetails->last_name); ?></p>
                    <p>City: <?php echo e($orderDetails->city); ?></p>
                    <p>State: <?php echo e($orderDetails->state_county); ?></p>
                    <p>Post Code: <?php echo e($orderDetails->postcode); ?></p>
                    <p>Address: <?php echo e($orderDetails->address); ?></p>
                    <p>Street Address: <?php echo e($orderDetails->street_address); ?></p>
                    <p>Phone: <?php echo e($orderDetails->phone); ?></p>
                </div>

                <div class="mt-4">
                    <form action="<?php echo e(route('admin.order.confirm', $orderDetails->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <button type="submit" class="btn btn-success">Confirm Order</button>
                    </form>
                </div>
            </div>
        </div>

        <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\orders\orderDetails.blade.php ENDPATH**/ ?>