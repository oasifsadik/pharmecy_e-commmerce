

<?php $__env->startSection('admintitle'); ?>
    Appointment List
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
    <?php echo $__env->make('doctors.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('doctors.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

    <div class="br-mainpanel">
        <div class="br-pagetitle d-flex justify-content-between align-items-center">
            <i class="icon ion-ios-calendar-outline"></i>
            <div>
                <h4>Appointment List</h4>
                <p class="mg-b-0">Manage your patient appointments here.</p>
            </div>
        </div>

        <div class="br-pagebody">
            <div class="br-section-wrapper">
                <div class="table-wrapper">
                    <table id="datatable2" class="table display responsive nowrap">
                        <thead>
                            <tr>
                                <th class="wd-5p">#SL</th>
                                <th class="wd-20p">Patient Name</th>
                                <th class="wd-10p">Age</th>
                                <th class="wd-20p">Symptoms</th>
                                <th class="wd-15p">Appointment Date</th>
                                <th class="wd-20p">Reports</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $sl = 1; ?>
                            <?php $__currentLoopData = $appointmentList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $appointment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($sl++); ?></td>
                                    <td><?php echo e($appointment->patient_name); ?></td>
                                    <td><?php echo e($appointment->age); ?></td>
                                    <td><?php echo e($appointment->symptoms); ?></td>
                                    <td><?php echo e($appointment->appointment_date); ?></td>
                                    <td>
                                        <?php $__currentLoopData = $appointment->files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <a href="<?php echo e(asset('storage/' . $file->file_path)); ?>" target="_blank">View</a><br>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div><!-- table-wrapper -->
            </div><!-- br-section-wrapper -->
        </div><!-- br-pagebody -->

        <?php echo $__env->make('doctors.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    </div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js__'); ?>
<script>
    $('#datatable2').DataTable({
        bLengthChange: false,
        searching: false,
        responsive: true
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('doctors.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views/doctors/appointmentList.blade.php ENDPATH**/ ?>