<?php $__env->startSection('admintitle'); ?>
Product Show
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <style>
        .image-container {
    position: relative;
    display: inline-block;
    margin: 5px;
}

.image-overlay {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(0, 0, 0, 0.5);
    color: white;
    display: flex;
    justify-content: center;
    align-items: center;
    opacity: 0;
    transition: opacity 0.3s ease;
}

.image-container:hover .image-overlay {
    opacity: 1;
}

.edit-btn, .delete-btn {
    /* background-color: rgba(255, 255, 255, 0.8); */
    border: none;
    padding: 5px 10px;
    margin: 0 5px;
    cursor: pointer;
}

.edit-btn:hover, .delete-btn:hover {
    /* background-color: white; */
}

    </style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboardContent'); ?>
<?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<div class="br-mainpanel">
    <div class="br-pagetitle d-flex justify-content-between align-items-center">
        <i class="icon ion-ios-folder-outline"></i>
        <div>
            <h4>Show Product</h4>
            <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(route('products.index')); ?>" class="btn btn-primary">Back</a>
        </div>
    </div>


    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper">
                <table id="" class="table display responsive nowrap">
                    <thead>
                        <tr class="table-hover">
                            <th class="">Category name</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->product_name); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th class="">Product Slug</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->product_slug); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th class="">Product Quantity</th>
                            <th class="">:</th>
                            <?php if(!empty($product->product_quantity)): ?>
                                <th><?php echo e($product->product_quantity); ?></th>
                                <?php else: ?>
                                <th class="text-danger">Out Of Stock</th>
                            <?php endif; ?>
                        </tr>
                        <?php if($product->color): ?>
                            <tr class="table-hover">
                                <th class="">Product Color</th>
                                <th class="">:</th>
                                <th class=""><?php echo e($product->color); ?></th>
                            </tr>
                        <?php endif; ?>
                        <?php if($product->size): ?>
                        <tr class="table-hover">
                            <th class="">Product Size</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->size); ?></th>
                        </tr>
                        <?php endif; ?>
                        <tr class="table-hover">
                            <th class="">Bying Price</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->buying_price); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th class="">Selling Price</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->selling_price); ?></th>
                        </tr>
                        <?php if($product->discount_type): ?>
                        <tr class="table-hover">
                            <th class="">Discount type</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->discount_type); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th class="">Discount Value</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->discount_value); ?> <sup class="badge badge-info"><?php echo e($product->discount_type); ?></sup> </th>
                        </tr>
                        <tr class="table-hover">
                            <th class="">Discount Price</th>
                            <th class="">:</th>
                            <th class=""><?php echo e($product->discount_price); ?></th>
                        </tr>
                        <?php endif; ?>
                        <tr class="table-hover">
                            <th class="">Image</th>
                            <th class="">:</th>
                            <th class="images">
                                <?php if($product->images()->exists()): ?>
                                    <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="image-container" data-id="<?php echo e($image->id); ?>">
                                            <img src="<?php echo e(asset('storage/' . $image->image_path)); ?>" height="100px" alt="Product Image">
                                            <div class="image-overlay">
                                                <button class="edit-btn btn-outline-primary rounded" onclick="editImage(<?php echo e($image->id); ?>)"><i class="fa fa-edit"></i></button>
                                                <form method="POST" action="" class="delete-form" onsubmit="return confirm('Are you sure you want to delete this image?');">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="delete-btn btn-outline-danger rounded"><i class="fa fa-trash"></i></button>
                                                </form>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p>No images found for this product.</p>
                                <?php endif; ?>
                            </th>
                        </tr>
                        <?php if($product->description): ?>
                        <tr class="table-hover">
                            <th class="">Discount type</th>
                            <th class="">:</th>
                            <th class=""><?php echo $product->description; ?></th>
                        </tr>
                        </tr>
                        <?php endif; ?>

                    </thead>
                </table>
            </div><!-- table-wrapper -->


        </div><!-- br-section-wrapper -->
    </div>
    <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\product\show.blade.php ENDPATH**/ ?>