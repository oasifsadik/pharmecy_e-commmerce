<?php $__env->startSection('admintitle'); ?>
Ambulance Booking Show
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
<?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<div class="br-mainpanel">
    <div class="br-pagetitle d-flex justify-content-between align-items-center">
        <i class="icon ion-ios-medkit-outline"></i>
        <div>
            <h4>Show Ambulance Booking</h4>
            <p class="mg-b-0">Detailed information about the booking.</p>
        </div>
        <div class="ml-auto">
            <a href="<?php echo e(route('admin.ambulance.booking.List')); ?>" class="btn btn-primary">Back</a>
        </div>
    </div>

    <div class="br-pagebody">
        <div class="br-section-wrapper">
            <div class="table-wrapper">
                <table class="table display responsive nowrap">
                    <thead>
                        <tr class="table-hover">
                            <th>ID</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->id); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>User ID</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->user_id); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Ambulance ID</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->ambulance_id); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Contact Number</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->contact_number); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Pickup Location</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->pickup_location); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Drop Location</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->drop_location); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Pickup Time</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->pickup_time); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Distance</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->distance ?? 'N/A'); ?> km</th>
                        </tr>
                        <tr class="table-hover">
                            <th>Price</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->price ?? 'N/A'); ?> Tk</th>
                        </tr>
                        <tr class="table-hover">
                            <th>Status</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->status); ?></th>
                        </tr>
                        <tr class="table-hover">
                            <th>Created At</th>
                            <th>:</th>
                            <th><?php echo e($ambulanceBooking->created_at); ?></th>
                        </tr>
                    </thead>
                </table>

                
                <?php if($ambulanceBooking->status === 'Pending'): ?>
                    <form action="<?php echo e(route('ambulanceBooking.confirm', $ambulanceBooking->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('PATCH'); ?>
                        <button type="submit" class="btn btn-success mt-3">Confirm Booking</button>
                    </form>
                <?php endif; ?>

            </div><!-- table-wrapper -->
        </div><!-- br-section-wrapper -->
    </div>
    <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\ambulanceBooking\show.blade.php ENDPATH**/ ?>