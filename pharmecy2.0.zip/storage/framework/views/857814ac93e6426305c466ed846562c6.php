<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>New Lab Booking</title>
</head>
<body>
    <h2>New Booking Notification</h2>
    <p><strong>Name:</strong> <?php echo e($data->name); ?></p>
    <p><strong>Email:</strong> <?php echo e($data->email); ?></p>
    <p><strong>Test:</strong> <?php echo e($data->labTest->name); ?></p>
    <p><strong>Date:</strong> <?php echo e(\Carbon\Carbon::parse($data->test_date)->format('F j, Y')); ?></p>
    <p><strong>Amount:</strong> <?php echo e($data->amount); ?> <?php echo e($data->currency); ?></p>
    <p><strong>Transaction ID:</strong> <?php echo e($data->transaction_id); ?></p>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\email\bookingAdmin.blade.php ENDPATH**/ ?>