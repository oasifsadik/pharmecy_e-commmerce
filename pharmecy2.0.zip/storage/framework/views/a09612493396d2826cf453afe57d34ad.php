<?php $__env->startSection('medwebtitle'); ?>
    Home
<?php $__env->stopSection(); ?>
<?php $__env->startSection('mw-css'); ?>
<style>
    /* Sidebar Styling */
    .sidebar {
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar-title {
        font-size: 18px;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    .list-group-item {
        border: none;
        padding: 10px 0;
    }

    .sidebar-link {
        display: block;
        font-size: 16px;
        color: #333;
        text-decoration: none;
        padding: 10px 15px;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    /* Hover effect */
    .sidebar-link:hover {
        background-color: #175CFF33;
        color: #175CFF;
        box-shadow: 0 2px 10px rgba(23, 92, 255, 0.2);
        border-left: 4px solid #175CFF;
    }

    /* Active state */
    .sidebar-link.active {
        background-color: #175CFF33;
        color: #175CFF;
        box-shadow: 0 2px 10px rgba(23, 92, 255, 0.2);
        border-left: 4px solid #175CFF;
    }

    .list-group-item:not(:last-child) {
        margin-bottom: 10px;
    }

    /* Profile Styling */
    .profile-container {
        background-color: #f8f9fa;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        padding: 30px;
    }

    .profile-title {
        font-size: 22px;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
        border-bottom: 2px solid #ddd;
        padding-bottom: 10px;
    }

    .profile-details {
        display: flex;
        flex-wrap: wrap;
        gap: 20px;
    }

    .profile-item {
        flex: 1 1 48%;
        background-color: #fff;
        padding: 15px;
        border-radius: 8px;
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.1);
    }

    .profile-item h5 {
        font-size: 16px;
        font-weight: bold;
        color: #333;
        margin-bottom: 8px;
    }

    .profile-item p {
        font-size: 14px;
        color: #555;
    }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('medWebContent'); ?>
<div class="container mt-5 p-3">
    <div class="row">
        <!-- Sidebar -->
        <div class="col-md-3">
            <div class="sidebar">
                <h3 class="sidebar-title">User Menu</h3>
                <ul class="list-group">
                    <li class="list-group-item">
                        <a href="<?php echo e(route('user.profile', auth()->user()->id)); ?>" class="sidebar-link <?php echo e(Request::routeIs('user.profile') ? 'active' : ''); ?>">Profile</a>
                    </li>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('user.order', auth()->user()->id)); ?>" class="sidebar-link <?php echo e(Request::routeIs('user.order') ? 'active' : ''); ?>">Orders</a>
                    </li>
                    <li class="list-group-item">
                        <a href="<?php echo e(route('user.order.deliver', auth()->user()->id)); ?>" class="sidebar-link <?php echo e(Request::routeIs('user.order.deliver', auth()->user()->id) ? 'active':''); ?>">Deliver Order</a>
                    </li>
                </ul>
            </div>
        </div>

        <!-- Main Content -->
        <div class="col-md-9">
            <div class="orders-container">
                <h3 class="orders-title">Your Orders</h3>

                <?php if($userOrders->isEmpty()): ?>
                    <p>No orders found.</p>
                <?php else: ?>
                    <?php $__currentLoopData = $userOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="order-item">
                            <h5>Order #<?php echo e($order->id); ?></h5>
                            <p>Status: <?php echo e($order->status); ?></p>
                            <p>Total Amount: $<?php echo e($order->total_amount); ?></p>
                            <p>Order Date: <?php echo e($order->created_at->format('d M, Y')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <!-- Pagination Links -->
                    <div class="pagination-links">
                        <?php echo e($userOrders->links()); ?>

                    </div>
                <?php endif; ?>
            </div>
        </div>

    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('medWebsite.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\medWebsite\profile\deliverOrder.blade.php ENDPATH**/ ?>