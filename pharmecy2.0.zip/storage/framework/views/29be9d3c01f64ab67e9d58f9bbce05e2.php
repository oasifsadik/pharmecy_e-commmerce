<?php $__env->startSection('medwebtitle'); ?>
    Home
<?php $__env->stopSection(); ?>

<?php $__env->startSection('medWebContent'); ?>
    <!-- SLIDER AREA START (slider-3) -->
    <div class="ltn__slider-area ltn__slider-3---  section-bg-1--- mt-30">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ltn__slide-active-2 slick-slide-arrow-1 slick-slide-dots-1 mb-30">
                        <!-- ltn__slide-item -->
                        <div class="ltn__slide-item ltn__slide-item-10 section-bg-1 bg-image" data-bs-bg="<?php echo e(asset('medWeb')); ?>/img/slider/71.jpg">
                            <div class="ltn__slide-item-inner">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-7 col-md-7 col-sm-7 align-self-center">
                                            <div class="slide-item-info">
                                                <div class="slide-item-info-inner ltn__slide-animation">
                                                    <h6 class="slide-sub-title ltn__secondary-color animated">Welcome To Our Shop</h6>
                                                    <h1 class="slide-title  animated">BanglaMeds</h1>
                                                    <div class="slide-brief animated d-none">
                                                        <p>Predictive analytics is drastically changing the real estate industry. In the past, providing data for quick</p>
                                                    </div>
                                                    <h5 class="color-orange  animated">A Comprehensive Online Pharmacy Solution</h5>
                                                    <div class="btn-wrapper  animated">
                                                        <a href="shop.html" class="theme-btn-1 btn btn-effect-1">Shop now</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-5 col-sm-5 align-self-center">
                                            <div class="slide-item-img">
                                                <!-- <a href="shop.html"><img src="img/product/1.png" alt="Image"></a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- ltn__slide-item -->
                        <div class="ltn__slide-item ltn__slide-item-10 section-bg-1 bg-image" data-bs-bg="<?php echo e(asset('medWeb')); ?>/img/slider/62.jpg">
                            <div class="ltn__slide-item-inner">
                                <div class="container">
                                    <div class="row">
                                        <div class="col-lg-7 col-md-7 col-sm-7 align-self-center">
                                            <div class="slide-item-info">
                                                <div class="slide-item-info-inner ltn__slide-animation">
                                                    <h4 class="slide-sub-title ltn__secondary-color animated text-uppercase">Welcome to our shop</h4>
                                                    <h1 class="slide-title  animated">TGold Standard <br>Pre-Workout</h1>
                                                    <div class="slide-brief animated d-none">
                                                        <p>Predictive analytics is drastically changing the real estate industry. In the past, providing data for quick</p>
                                                    </div>
                                                    <div class="btn-wrapper  animated">
                                                        <a href="shop.html" class="theme-btn-1 btn btn-effect-1 text-uppercase">Shop now</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-5 col-md-5 col-sm-5 align-self-center">
                                            <div class="slide-item-img">
                                                <!-- <a href="shop.html"><img src="img/slider/62.jpg" alt="Image"></a> -->
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
            </div>
        </div>
    </div>
    <!-- SLIDER AREA END -->

    <!-- CATEGORY AREA START -->
    <div class="ltn__category-area section-bg-1-- pt-30 pb-50">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h1 class="section-title">OTC Medicine</h1>
                    </div>
                </div>
            </div>
            <div class="row ltn__category-slider-active-six slick-arrow-1 border-bottom">
                <div class="col-12">
                    <div class="ltn__category-item ltn__category-item-6 text-center">
                        <div class="ltn__category-item-img">
                            <a href="<?php echo e(route('medicine.generic', ['name' => 'Fever'])); ?>">
                                <i class="fas fa-notes-medical"></i>
                            </a>
                        </div>
                        <div class="ltn__category-item-name">
                            <h6><a href="<?php echo e(route('medicine.generic', ['name' => 'Fever'])); ?>">Fever</a></h6>
                        </div>
                    </div>
                </div>

    <div class="col-12">
        <div class="ltn__category-item ltn__category-item-6 text-center">
            <div class="ltn__category-item-img">
                <a href="<?php echo e(route('medicine.generic', ['name' => 'Headache'])); ?>">
                    <i class="fas fa-box-tissue"></i>
                </a>
            </div>
            <div class="ltn__category-item-name">
                <h6><a href="<?php echo e(route('medicine.generic', ['name' => 'Headache'])); ?>">Headache</a></h6>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="ltn__category-item ltn__category-item-6 text-center">
            <div class="ltn__category-item-img">
                <a href="<?php echo e(route('medicine.generic', ['name' => 'Diarrhea'])); ?>">
                    <i class="fas fa-pump-medical"></i>
                </a>
            </div>
            <div class="ltn__category-item-name">
                <h6><a href="<?php echo e(route('medicine.generic', ['name' => 'Diarrhea'])); ?>">Diarrhea</a></h6>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="ltn__category-item ltn__category-item-6 text-center">
            <div class="ltn__category-item-img">
                <a href="<?php echo e(route('medicine.generic', ['name' => 'Eczema'])); ?>">
                    <i class="fas fa-bong"></i>
                </a>
            </div>
            <div class="ltn__category-item-name">
                <h6><a href="<?php echo e(route('medicine.generic', ['name' => 'Eczema'])); ?>">Eczema</a></h6>
            </div>
        </div>
    </div>

    <div class="col-12">
        <div class="ltn__category-item ltn__category-item-6 text-center">
            <div class="ltn__category-item-img">
                <a href="<?php echo e(route('medicine.generic', ['name' => 'Pregnancy'])); ?>">
                    <i class="fas fa-tooth"></i>
                </a>
            </div>
            <div class="ltn__category-item-name">
                <h6><a href="<?php echo e(route('medicine.generic', ['name' => 'Pregnancy'])); ?>">Pregnancy</a></h6>
            </div>
        </div>
    </div>
</div>

        </div>
    </div>
    <!-- CATEGORY AREA END -->

    <!-- PRODUCT AREA START (product-item-3) -->
    
    <!-- PRODUCT AREA END -->

    <!-- COUNTDOWN AREA START -->
    
    <!-- COUNTDOWN AREA END -->

    <!-- PRODUCT AREA START (product-item-3) -->
    
<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="ltn__product-area ltn__product-gutter no-product-ratting pt-115 pb-70---">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="section-title-area ltn__section-title-2 text-center">
                    <h1 class="section-title"><?php echo e($category->category_name); ?></h1>
                </div>
            </div>
        </div>

        <div class="row ltn__tab-product-slider-one-active--- slick-arrow-1">
            <?php $__currentLoopData = $category->product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php $__currentLoopData = $item->Stock; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-lg-3--- col-md-3 col-sm-6 col-6">
                    <div class="ltn__product-item ltn__product-item-2 text-left">
                        <div class="product-img">
                            <a href="<?php echo e(route('singleProduct', $stock->id)); ?>">
                                <img src="<?php echo e(asset('storage/' . $item->thumbnail)); ?>" alt="#">
                            </a>
                            <div class="product-badge">
                                <ul>
                                    <li class="sale-badge">New</li>
                                </ul>
                            </div>
                            <div class="product-hover-action">
                                <ul>
                                    <li>
                                        <a href="#" title="Quick View" data-bs-toggle="modal" data-bs-target="#quick_view_modal">
                                            <i class="far fa-eye"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" title="Add to Cart" data-bs-toggle="modal" data-bs-target="#add_to_cart_modal">
                                            <i class="fas fa-shopping-cart"></i>
                                        </a>
                                    </li>
                                    <li>
                                        <a href="#" title="Wishlist" data-bs-toggle="modal" data-bs-target="#liton_wishlist_modal">
                                            <i class="far fa-heart"></i>
                                        </a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="product-info">
                            <div class="product-ratting">
                                <ul>
                                    <li><a href="#"><i class="fas fa-star"></i></a></li>
                                    <li><a href="#"><i class="fas fa-star"></i></a></li>
                                    <li><a href="#"><i class="fas fa-star"></i></a></li>
                                    <li><a href="#"><i class="fas fa-star-half-alt"></i></a></li>
                                    <li><a href="#"><i class="far fa-star"></i></a></li>
                                </ul>
                            </div>
                            <h2 class="product-title">
                                <a href="<?php echo e(route('singleProduct', $stock->id)); ?>"><?php echo e($stock->product->product_name); ?></a>
                            </h2>
                            <div class="product-price">
                                <?php if($stock->discount_price): ?>
                                    <span><?php echo e($stock->discount_price); ?></span>
                                    <del><?php echo e($stock->selling_price); ?></del>
                                <?php else: ?>
                                    <span><?php echo e($stock->selling_price); ?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


    <!-- PRODUCT AREA END -->

    <!-- BANNER AREA START -->
    
    <!-- BANNER AREA END -->

    <!-- SMALL PRODUCT LIST AREA START -->
    
    <!-- SMALL PRODUCT LIST AREA END -->

    <!-- PRODUCT AREA START (product-item-3) -->
    <div class="ltn__product-area ltn__product-gutter pt-115 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="section-title-area ltn__section-title-2 text-center">
                        <h1 class="section-title">Medicine</h1>
                    </div>
                </div>
            </div>
            <div class="row ltn__tab-product-slider-one-active--- slick-arrow-1">
                <!-- ltn__product-item -->
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stock): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-lg-3 col-md-4 col-sm-6 col-6">
                        <div class="ltn__product-item ltn__product-item-3 text-left">
                            <div class="product-img">
                                <a href="product-details.html"><img src="<?php echo e(asset('storage/'. $stock->product->thumbnail)); ?>" alt="#"></a>
                                <div class="product-badge">
                                    <ul>
                                        <li class="sale-badge">New</li>
                                    </ul>
                                </div>
                                <div class="product-hover-action">
                                    <ul>
                                        <li>
                                            <a href="#" title="Quick View" data-bs-toggle="modal" data-bs-target="#quick_view_modal">
                                                <i class="far fa-eye"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" title="Add to Cart" data-bs-toggle="modal" data-bs-target="#add_to_cart_modal">
                                                <i class="fas fa-shopping-cart"></i>
                                            </a>
                                        </li>
                                        <li>
                                            <a href="#" title="Wishlist" data-bs-toggle="modal" data-bs-target="#liton_wishlist_modal">
                                                <i class="far fa-heart"></i></a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-info">
                                <div class="product-ratting">
                                    <ul>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star"></i></a></li>
                                        <li><a href="#"><i class="fas fa-star-half-alt"></i></a></li>
                                        <li><a href="#"><i class="far fa-star"></i></a></li>
                                    </ul>
                                </div>
                                <h2 class="product-title"><a href="product-details.html"><?php echo e($stock->product->product_name); ?></a></h2>
                                <div class="product-price">
                                    <?php if($stock->discount_price): ?>
                                            <span><?php echo e($stock->discount_price); ?></span>
                                            <del><?php echo e($stock->selling_price); ?></del>
                                        <?php else: ?>
                                            <span><?php echo e($stock->selling_price); ?></span>
                                        <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- PRODUCT AREA END -->

    <!-- ABOUT US AREA START -->
    
    <!-- ABOUT US AREA END -->


    <!-- FEATURE AREA START ( Feature - 3) -->
    <div class="ltn__feature-area section-bg-1 mt-90--- pt-30 pb-30 mt--65---">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="ltn__feature-item-box-wrap ltn__feature-item-box-wrap-2 ltn__border--- section-bg-1">
                        <div class="ltn__feature-item ltn__feature-item-8">
                            <div class="ltn__feature-icon">
                                <img src="<?php echo e(asset('medWeb')); ?>/img/icons/svg/8-trolley.svg" alt="#">
                            </div>
                            <div class="ltn__feature-info">
                                <h4>Free shipping</h4>
                                <p>On all orders over $49.00</p>
                            </div>
                        </div>
                        <div class="ltn__feature-item ltn__feature-item-8">
                            <div class="ltn__feature-icon">
                                <img src="<?php echo e(asset('medWeb')); ?>/img/icons/svg/9-money.svg" alt="#">
                            </div>
                            <div class="ltn__feature-info">
                                <h4>15 days returns</h4>
                                <p>Moneyback guarantee</p>
                            </div>
                        </div>
                        <div class="ltn__feature-item ltn__feature-item-8">
                            <div class="ltn__feature-icon">
                                <img src="<?php echo e(asset('medWeb')); ?>/img/icons/svg/10-credit-card.svg" alt="#">
                            </div>
                            <div class="ltn__feature-info">
                                <h4>Secure checkout</h4>
                                <p>Protected by Paypal</p>
                            </div>
                        </div>
                        <div class="ltn__feature-item ltn__feature-item-8">
                            <div class="ltn__feature-icon">
                                <img src="<?php echo e(asset('medWeb')); ?>/img/icons/svg/11-gift-card.svg" alt="#">
                            </div>
                            <div class="ltn__feature-info">
                                <h4>Offer & gift here</h4>
                                <p>On all orders over</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- FEATURE AREA END -->

    <!-- CALL TO ACTION START (call-to-action-6) -->
    <div class="ltn__call-to-action-area call-to-action-6 before-bg-bottom d-none" data-bs-bg="img/1.jpg--">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="call-to-action-inner call-to-action-inner-6 ltn__secondary-bg position-relative text-center---">
                        <div class="coll-to-info text-color-white">
                            <h1>Buy medical disposable face mask <br> to protect your loved ones</h1>
                        </div>
                        <div class="btn-wrapper">
                            <a class="btn btn-effect-3 btn-white" href="shop.html">Explore Products <i class="icon-next"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- CALL TO ACTION END -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('medWebsite.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\medWebsite\home.blade.php ENDPATH**/ ?>