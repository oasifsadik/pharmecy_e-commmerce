<?php $__env->startSection('admintitle'); ?>
    Category Show
<?php $__env->stopSection(); ?>
<?php $__env->startSection('dashboardContent'); ?>
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <div class="br-mainpanel">
        <div class="br-pagetitle d-flex justify-content-between align-items-center">
            <i class="icon ion-ios-folder-outline"></i>
            <div>
                <h4>Show Category</h4>
                <p class="mg-b-0">Do bigger things with Bracket plus, the responsive bootstrap 4 admin template.</p>
            </div>
            <div class="ml-auto">
                <a href="<?php echo e(route('category.index')); ?>" class="btn btn-primary">Back</a>
            </div>
        </div>


       <div class="br-pagebody">
        <div class="br-section-wrapper">
          <div class="table-wrapper">
            <table id="" class="table display responsive nowrap">
              <thead>
                <tr class="table-hover">
                  <th class="">Category name</th>
                  <th class="">:</th>
                  <th class=""><?php echo e($category->category_name); ?></th>
                </tr>
                <tr class="table-hover">
                  <th class="">Category Description</th>
                  <th class="">:</th>
                  <th class=""><?php echo e($category->category_description); ?></th>
                </tr>
              </thead>
            </table>
          </div><!-- table-wrapper -->


        </div><!-- br-section-wrapper -->
      </div>
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\category\show.blade.php ENDPATH**/ ?>