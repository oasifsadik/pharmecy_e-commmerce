<?php $__env->startSection('medwebtitle'); ?>
Lab Test Booking
<?php $__env->stopSection(); ?>

<?php $__env->startSection('medWebContent'); ?>
<!-- BREADCRUMB AREA START -->
<div class="ltn__breadcrumb-area text-left bg-overlay-white-30 bg-image"  data-bs-bg="<?php echo e(asset('medWeb')); ?>/img/bg/14.jpg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="ltn__breadcrumb-inner">
                    <h1 class="page-title">Ambulances Booking</h1>
                    <div class="ltn__breadcrumb-list">
                        <ul>
                            <li><a href="<?php echo e(route('home')); ?>"><span class="ltn__secondary-color"><i class="fas fa-home"></i></span> Home</a></li>
                            <li>Lab Test</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- BREADCRUMB AREA END -->

<!-- PRODUCT DETAILS AREA START -->
<div class="ltn__product-area ltn__product-gutter mb-120">
    <div class="container">
        <div class="row">
            <div class="col-lg-12">
                <div class="container my-4">
                    <div class="row">
                        <!-- Left Side: Ambulance Info -->
                        <div class="col-lg-6 mb-4">
                            <div class="product-img">
                                <a href="#">
                                    <img src="<?php echo e(asset($labtest->image)); ?>" alt="<?php echo e($labtest->name); ?>" style="width: 100%; height: 300px; object-fit: cover; border-radius: 8px;">
                                </a>
                                <div class="product-badge">
                                    <ul>
                                        <li class="sale-badge"></li>
                                    </ul>
                                </div>
                            </div>
                            <div class="product-info mt-3 p-3 border rounded shadow-sm">
                                
                                <h2 class="product-title"><?php echo e($labtest->name); ?></h2>

                                <p><strong>Test Code:</strong> <?php echo e($labtest->test_code); ?></p>
                                <p><strong>Description:</strong> <?php echo e($labtest->description); ?></p>

                                
                                <p><strong>Price:</strong>
                                    <span class="badge bg-primary">৳ <?php echo e(number_format($labtest->price, 2)); ?></span>
                                </p>

                                
                                <hr>
                                <h5 class="mt-3">Hospital Information</h5>

                                <p><strong>Name:</strong> <?php echo e($labtest->hospital_name); ?></p>
                                <p><strong>Division:</strong> <?php echo e($labtest->hospital_division); ?></p>
                                <p><strong>District:</strong> <?php echo e($labtest->hospital_district); ?></p>
                                <p><strong>Upazila:</strong> <?php echo e($labtest->hospital_upazila); ?></p>

                                <?php if($labtest->hospital_union): ?>
                                    <p><strong>Union:</strong> <?php echo e($labtest->hospital_union); ?></p>
                                <?php endif; ?>

                                <?php if($labtest->hospital_ward): ?>
                                    <p><strong>Ward:</strong> <?php echo e($labtest->hospital_ward); ?></p>
                                <?php endif; ?>

                                <p><strong>Address:</strong> <?php echo e($labtest->hospital_address); ?></p>

                                <?php if($labtest->hospital_post_code): ?>
                                    <p><strong>Post Code:</strong> <?php echo e($labtest->hospital_post_code); ?></p>
                                <?php endif; ?>

                                <?php if($labtest->hospital_phone): ?>
                                    <p><strong>Phone:</strong> <?php echo e($labtest->hospital_phone); ?></p>
                                <?php endif; ?>

                                <?php if($labtest->hospital_email): ?>
                                    <p><strong>Email:</strong>
                                        <a href="mailto:<?php echo e($labtest->hospital_email); ?>"><?php echo e($labtest->hospital_email); ?></a>
                                    </p>
                                <?php endif; ?>

                                <?php if($labtest->hospital_website): ?>
                                    <p><strong>Website:</strong>
                                        <a href="<?php echo e($labtest->hospital_website); ?>" target="_blank"><?php echo e($labtest->hospital_website); ?></a>
                                    </p>
                                <?php endif; ?>

                                
                                <p><strong>Status:</strong>
                                    <?php if($labtest->status == 'Active'): ?>
                                        <span class="badge bg-success">Active</span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary">In-Active</span>
                                    <?php endif; ?>
                                </p>
                            </div>

                        </div>

                        <!-- Right Side: Booking Form -->
                        <div class="col-lg-6">
                            <div class="card shadow-sm p-4">
                                <h4 class="mb-3">Book This Ambulance</h4>
                                <form id="booking-form" action="<?php echo e(url('/pay')); ?>" method="POST">

                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" />
                                    <input type="hidden" name="lab_test_id" value="<?php echo e($labtest->id); ?>">
                                    <input type="hidden" name="total_amount" value="<?php echo e($labtest->price); ?>">

                                    <div class="mb-3">
                                        <label for="patient_name" class="form-label">Patient Name</label>
                                        <input type="text" class="form-control" name="patient_name" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="contact_number" class="form-label">Contact Number</label>
                                        <input type="text" class="form-control" name="contact_number" required>
                                    </div>


                                    <div class="mb-3">
                                        <label for="email" class="form-label">Email Address</label>
                                        <input type="email" class="form-control" name="email" required>
                                    </div>

                                    <div class="mb-3">
                                        <label for="address" class="form-label">Address</label>
                                        <input type="text" class="form-control" name="address">
                                    </div>

                                    <div class="mb-3">
                                        <label for="test_date" class="form-label">Preferred Test Date</label>
                                        <input type="date" class="form-control" name="test_date" required>
                                    </div>

                                    <button class="btn btn-primary btn-lg btn-block" type="submit">Continue to checkout</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- PRODUCT DETAILS AREA END -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('font-js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('medWebsite.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\medWebsite\lab\labBookingForm.blade.php ENDPATH**/ ?>