<div class="header-top">
                    <div class="container">
                        <div class="row">
                            <!-- Begin Header Top Left Area -->
                            <div class="col-lg-3 col-md-4">
                                <div class="header-top-left">
                                    <ul class="phone-wrap">
                                        <li><span>Telephone Enquiry:</span><a href="#">01705825277</a></li>
                                    </ul>
                                </div>
                            </div>
                            <!-- Header Top Left Area End Here -->
                            <!-- Begin Header Top Right Area -->
                            <div class="col-lg-9 col-md-8">
                                <div class="header-top-right">
                                    <ul class="ht-menu">
                                        <!-- Begin Setting Area -->
                                        <li><?php if(Auth::check()): ?>
                                            <div class="ht-setting-trigger"><span><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></span></div>
                                        <?php else: ?>
                                        <div class="ht-setting-trigger"><span>Setting</span></div>
                                        <?php endif; ?>

                                            <div class="setting ht-setting">
                                                <ul class="ht-setting-list">
                                                    <?php if(Auth::check()): ?>
                                                    <li><a href="<?php echo e(route('user.profile', auth()->user()->id)); ?>">My Account</a></li>
                                                    <li><a href="checkout.html">Checkout</a></li>
                                                    <?php endif; ?>



                                                    <?php if(Auth::check()): ?>
                                                    <li>
                                                        <a href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">Sign Out</a>
                                                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                                                            <?php echo csrf_field(); ?>
                                                        </form>
                                                    </li>
                                                    <?php else: ?>
                                                    <li>
                                                        <a href="<?php echo e(route('login')); ?>">Sign In</a>

                                                    </li>
                                                    <?php endif; ?>
                                                </ul>
                                            </div>
                                        </li>
                                        <!-- Setting Area End Here -->
                                        <!-- Begin Currency Area -->
                                        
                                        <!-- Currency Area End Here -->
                                        <!-- Begin Language Area -->
                                        
                                        <!-- Language Area End Here -->
                                    </ul>
                                </div>
                            </div>
                            <!-- Header Top Right Area End Here -->
                        </div>
                    </div>
                </div>
<?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\website\layout\topHeader.blade.php ENDPATH**/ ?>