<?php $__env->startSection('medwebtitle'); ?>
    Message
<?php $__env->stopSection(); ?>

<?php $__env->startSection('mw-css'); ?>
<style>
    .sidebar {
        padding: 20px;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
    }

    .sidebar-title {
        font-size: 18px;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
        border-bottom: 1px solid #ddd;
        padding-bottom: 10px;
    }

    .list-group-item {
        border: none;
        padding: 10px 0;
    }

    .sidebar-link {
        display: block;
        font-size: 16px;
        color: #333;
        text-decoration: none;
        padding: 10px 15px;
        border-radius: 4px;
        transition: all 0.3s ease;
    }

    .sidebar-link:hover {
        background-color: #175CFF33;
        color: #175CFF;
        border-left: 4px solid #175CFF;
    }

    .sidebar-link.active {
        background-color: #175CFF33;
        color: #175CFF;
        border-left: 4px solid #175CFF;
    }

    .profile-container {
        background-color: #f8f9fa;
        border-radius: 8px;
        box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        padding: 30px;
    }

    .profile-title {
        font-size: 22px;
        font-weight: bold;
        color: #333;
        margin-bottom: 20px;
        border-bottom: 2px solid #ddd;
        padding-bottom: 10px;
    }

    .chat-box {
        background-color: #fff;
        border: 1px solid #ddd;
        border-radius: 8px;
        height: 300px;
        overflow-y: auto;
        padding: 15px;
    }

    .chat-message.sent {
        background-color: #d1f7c4;
        text-align: right;
        padding: 10px;
        border-radius: 10px;
        margin-bottom: 8px;
        max-width: 75%;
        margin-left: auto;
    }

    .chat-message.received {
        background-color: #e2e3e5;
        text-align: left;
        padding: 10px;
        border-radius: 10px;
        margin-bottom: 8px;
        max-width: 75%;
        margin-right: auto;
    }
</style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('medWebContent'); ?>
<div class="container mt-5 p-3">
    <div class="row">
        <!-- Sidebar: Doctor List -->
        <div class="col-md-3">
            <div class="sidebar">
                <h3 class="sidebar-title">Your Doctors</h3>
                <ul class="list-group">
                    <?php $__currentLoopData = $doctors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doctorId => $appointments): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $doctor = $appointments->first()->doctor;
                        ?>
                        <li class="list-group-item">
                            <a href="<?php echo e(route('patient.chat.with', $doctorId)); ?>"
                               class="sidebar-link <?php echo e($selectedDoctorId == $doctorId ? 'active' : ''); ?>">
                                Dr. <?php echo e($doctor->name ?? 'N/A'); ?>

                            </a>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>

        <!-- Chat Section -->
        <div class="col-md-9">
            <div class="profile-container">
                <h3 class="profile-title">
                    Chat with Dr. <?php echo e($activeAppointment->doctor->name ?? 'Select a Doctor'); ?>

                </h3>

                <!-- Chat Box -->
                <div class="chat-box mb-3" id="chat-box">
                    <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="chat-message <?php echo e($msg->sender === 'patient' ? 'sent' : 'received'); ?>">
                            <?php echo e($msg->text); ?>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

                <!-- Message Input -->
                <?php if($activeAppointment): ?>
                    <form id="chatForm" method="POST" class="d-flex">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="patient_id" value="<?php echo e($activeAppointment->id); ?>">
                        <input type="text" name="text" id="messageInput" class="form-control me-2" placeholder="Type a message..." required>
                        <button type="submit" class="btn btn-primary">Send</button>
                    </form>
                <?php else: ?>
                    <p class="text-muted">Please select a doctor to start chatting.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    const appointmentId = "<?php echo e($activeAppointment->id ?? ''); ?>";

    function fetchMessages() {
        if (!appointmentId) return;
        $.get('/patient/chat/messages/' + appointmentId, function (data) {
            let html = '';
            data.forEach(msg => {
                const className = msg.sender === 'patient' ? 'sent' : 'received';
                html += `<div class="chat-message ${className}">${msg.text}</div>`;
            });
            $('#chat-box').html(html);
        });
    }

    fetchMessages();
    setInterval(fetchMessages, 3000);

    $('#chatForm').on('submit', function (e) {
        e.preventDefault();

        const text = $('#messageInput').val();
        if (!text.trim()) return;

        $.ajax({
            url: "<?php echo e(route('patient.chat.send')); ?>",
            method: "POST",
            data: {
                _token: '<?php echo e(csrf_token()); ?>',
                patient_id: appointmentId,
                text: text,
                sender: 'patient'
            },
            success: function () {
                $('#messageInput').val('');
                fetchMessages();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('medWebsite.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\medWebsite\profile\chat.blade.php ENDPATH**/ ?>