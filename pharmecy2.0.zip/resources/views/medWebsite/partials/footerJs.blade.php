    <!-- All JS Plugins -->
    <script src="{{ asset('medWeb') }}/js/plugins.js"></script>
    <!-- Main JS -->
    <script src="{{ asset('medWeb') }}/js/main.js"></script>
    @yield('font-js')
