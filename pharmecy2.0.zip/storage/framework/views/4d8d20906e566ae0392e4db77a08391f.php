<?php $__env->startSection('admintitle'); ?>
    Order History
<?php $__env->stopSection(); ?>

<?php $__env->startSection('dashboardContent'); ?>
     <!-- ########## START: LEFT PANEL ########## -->
     <?php echo $__env->make('admin.layout.slidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: LEFT PANEL ########## -->

     <!-- ########## START: HEAD PANEL ########## -->
         <?php echo $__env->make('admin.layout.navbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: HEAD PANEL ########## -->

     <!-- ########## START: RIGHT PANEL ########## -->
     <?php echo $__env->make('admin.layout.rightbar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     <!-- ########## END: RIGHT PANEL ########## -->

     <!-- ########## START: MAIN PANEL ########## -->
     <div class="br-mainpanel">
       <div class="br-pagetitle">
         <i class="icon ion-ios-list-outline"></i>
         <div>
           <h4>Order History</h4>
           <p class="mg-b-0">View and manage all past orders.</p>
         </div>
       </div>

       <div class="br-pagebody">
        <div class="br-section-wrapper">
            <h6 class="br-section-label">Order History</h6>
            <p class="br-section-text">Manage and review the history of all orders.</p>

            <!-- Search and Filter Form -->
            <form method="GET" action="<?php echo e(route('admin.orders.history')); ?>" class="mb-4">
                <div class="form-row">
                    <div class="col-md-4 mb-3">
                        <input type="text" name="search" class="form-control" placeholder="Search by Order ID or Name" value="<?php echo e(request()->get('search')); ?>">
                    </div>
                    <div class="col-md-4 mb-3">
                        <select name="status" class="form-control">
                            <option value="">All Statuses</option>
                            <option value="Pending" <?php echo e(request()->get('status') == 'Pending' ? 'selected' : ''); ?>>Pending</option>
                            <option value="Order Confirmed" <?php echo e(request()->get('status') == 'Order Confirmed' ? 'selected' : ''); ?>>Order Confirmed</option>
                            <option value="Shipped" <?php echo e(request()->get('status') == 'Shipped' ? 'selected' : ''); ?>>Shipped</option>
                            <option value="Canceled" <?php echo e(request()->get('status') == 'Canceled' ? 'selected' : ''); ?>>Canceled</option>
                            <option value="Delivered" <?php echo e(request()->get('status') == 'Delivered' ? 'selected' : ''); ?>>Delivered</option>
                        </select>
                    </div>
                    <div class="col-md-4 mb-3">
                        <button type="submit" class="btn btn-primary w-100">Search</button>
                    </div>
                </div>
            </form>

            <!-- Orders Table -->
            <div class="bd bd-gray-300 rounded table-responsive">
              <table class="table mg-b-0">
                <thead>
                  <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Total Price</th>
                    <th>Status</th>
                    <th>Order Date</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                    <th scope="row"><?php echo e($order->id); ?></th>
                    <td><?php echo e($order->first_name); ?> <?php echo e($order->last_name); ?></td>
                    <td><?php echo e($order->email); ?></td>
                    <td><?php echo e($order->phone); ?></td>
                    <td>$<?php echo e($order->total_price); ?></td>
                    <td><?php echo e($order->status); ?></td>
                    <td><?php echo e($order->created_at->format('d M, Y')); ?></td>
                    <td>
                        <a href="<?php echo e(route('admin.orders.details', $order->id)); ?>" class="btn btn-primary btn-sm"><i class="fa fa-eye"></i></a>
                    </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>

              <!-- Pagination Links -->
              <div class="pagination-wrapper mt-3">
                <?php echo e($orders->appends(request()->query())->links()); ?>

              </div>
            </div>
        </div>
       </div><!-- br-pagebody -->

       <!-- Include Footer -->
       <?php echo $__env->make('admin.layout.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
     </div><!-- br-mainpanel -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.master', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\xampp\htdocs\pharmecy2.0\resources\views\admin\orders\orderHistory.blade.php ENDPATH**/ ?>